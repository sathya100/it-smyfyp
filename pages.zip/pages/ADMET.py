import streamlit as st
import pandas as pd
import numpy as np
from rdkit import Chem
from rdkit.Chem import Descriptors
from sklearn.preprocessing import StandardScaler
import joblib

# Load the scaler and model
scaler = joblib.load('admet_scaler.pkl')
best_model = joblib.load('admet_model.pkl')

# Descriptor extraction function
def extract_descriptors(smiles):
    mol = Chem.MolFromSmiles(smiles)
    if mol is None:
        return None
    return [
        Descriptors.MolWt(mol),
        Descriptors.MolLogP(mol),
        Descriptors.TPSA(mol),
        Descriptors.NumHDonors(mol),
        Descriptors.NumHAcceptors(mol),
        Descriptors.NumRotatableBonds(mol),
        mol.GetNumAtoms(),
        Descriptors.HeavyAtomCount(mol),
        Descriptors.NumAromaticRings(mol),
        Descriptors.NumHeteroatoms(mol),
        Descriptors.MolMR(mol),
        Descriptors.Kappa1(mol),
        Descriptors.Kappa2(mol),
        Descriptors.Kappa3(mol),
        Descriptors.FractionCSP3(mol),
        Descriptors.RingCount(mol)
    ]

# Feature extraction function
def extract_features(smiles_list):
    features = [extract_descriptors(smiles) for smiles in smiles_list]
    return pd.DataFrame(features, columns=[
        'MolWt', 'LogP', 'TPSA', 'HDonorCount', 'HAcceptorCount', 'NumRotatableBonds',
        'NumAtoms', 'HeavyAtomCount', 'NumAromaticRings', 'NumHeteroatoms', 'MolMR',
        'Kappa1', 'Kappa2', 'Kappa3', 'Fraction_Csp3', 'NumRings'
    ])

# Property interpretation logic
def interpret_property(prop, value):
    if prop == 'HIA_Hou':
        return "🟢 Excellent" if value >= 30 else "🔴 Poor"
    elif prop == 'Caco2_Wang':
        return "🟢 Excellent" if value > -5.15 else "🔴 Poor"
    elif prop == 'Bioavailability_Ma':
        if value >= 0.7:
            return "🟢 High"
        elif value >= 0.3:
            return "🟡 Medium"
        else:
            return "🔴 Low"
    elif prop in ['CYP1A2_Veith', 'CYP2C19_Veith', 'CYP2C9_Veith', 'CYP2D6_Veith', 'CYP3A4_Veith']:
        if value <= 0.3:
            return "🟢 Low"
        elif value <= 0.7:
            return "🟡 Medium"
        else:
            return "🔴 High"
    elif prop == 'Clearance_Hepatocyte_AZ':
        return "🟢 Efficient" if value >= 5 else "🔴 Poor"
    elif prop == 'Half_Life_Obach':
        return "🟢 Long" if value >= 3 else "🔴 Short"
    elif prop == 'VDss_Lombardo':
        return "🟢 Excellent" if 0.04 <= value <= 20 else "🔴 Poor"
    elif prop in ['AMES', 'Carcinogens_Lagunin', 'DILI', 'hERG', 'Skin_Reaction']:
        if value <= 0.3:
            return "🟢 Excellent"
        elif value <= 0.7:
            return "🟡 Medium"
        else:
            return "🔴 Risky"
    elif prop == 'ClinTox':
        return "⚠️ High concern" if value > 0.5 else "✅ Low concern"
    elif prop == 'QED':
        if value >= 0.7:
            return "🟢 High"
        elif value >= 0.4:
            return "🟡 Medium"
        else:
            return "🔴 Low"
    elif prop == 'PAMPA_NCATS':
        return "🟢 High permeability" if value >= 0.5 else "🔴 Low permeability"
    elif prop == 'Pgp_Broccatelli':
        return "🟢 Non-substrate" if value <= 0.3 else "🔴 Substrate"
    elif prop == 'BBB_Martins':
        return "🟢 BBB permeable" if value >= 0.5 else "🔴 Not permeable"
    elif prop == 'PPBR_AZ':
        return "🟢 Low binding" if value <= 0.3 else "🔴 High binding"
    elif prop == 'Lipophilicity_AstraZeneca':
        if 1 <= value <= 3:
            return "🟢 Optimal"
        else:
            return "🔴 Suboptimal"
    elif prop in ['CYP2C9_Substrate_CarbonMangels', 'CYP2D6_Substrate_CarbonMangels', 'CYP3A4_Substrate_CarbonMangels']:
        if value <= 0.3:
            return "🟢 Low"
        elif value <= 0.7:
            return "🟡 Medium"
        else:
            return "🔴 High"
    elif prop == 'Clearance_Microsome_AZ':
        return "🟢 Efficient" if value >= 5 else "🔴 Poor"
    elif prop == 'molecular_weight':
        return "🟢 Acceptable" if 100 <= value <= 600 else "🔴 Outside range"
    elif prop == 'logP':
        return "🟢 Acceptable" if 1 <= value <= 3 else "🔴 Outside range"
    elif prop == 'hydrogen_bond_acceptors':
        return "🟢 Acceptable" if 0 <= value <= 12 else "🔴 Outside range"
    elif prop == 'hydrogen_bond_donors':
        return "🟢 Acceptable" if 0 <= value <= 7 else "🔴 Outside range"
    elif prop == 'Lipinski':
        return "🟢 Compliant" if value == 0 else "🔴 Violates"
    elif prop == 'stereo_centers':
        return "🟢 Acceptable" if value <= 3 else "🔴 Too many"
    elif prop == 'tpsa':
        return "🟢 Acceptable" if value <= 140 else "🔴 Too high"
    else:
        return f"{value:.4f}"

# Streamlit UI
st.set_page_config(page_title="ADMET Prediction App", layout="centered")
st.title("🧪 ADMET Property Predictor")
st.markdown("Enter a drug's **SMILES** string below to get predicted **ADMET** properties and their evaluations.")

smiles_input = st.text_input("🔬 Enter Drug SMILES:", "")

# Final properties to be interpreted
selected_admet = [
    'HIA_Hou', 'PAMPA_NCATS', 'Pgp_Broccatelli', 'Caco2_Wang', 'BBB_Martins', 'Bioavailability_Ma',  'PPBR_AZ', 'Lipophilicity_AstraZeneca', 
    'CYP1A2_Veith', 'CYP2C19_Veith', 'CYP2C9_Substrate_CarbonMangels',  'CYP2C9_Veith','CYP2D6_Substrate_CarbonMangels', 'CYP2D6_Veith', 'CYP3A4_Substrate_CarbonMangels', 
    'CYP3A4_Veith', 'Clearance_Hepatocyte_AZ', 'Clearance_Microsome_AZ','Half_Life_Obach', 'VDss_Lombardo',  'AMES',  'Carcinogens_Lagunin', 'ClinTox', 'DILI',  'hERG', 
    'Skin_Reaction', 'molecular_weight',  'logP',  'hydrogen_bond_acceptors', 'hydrogen_bond_donors',  'Lipinski',  'QED',  'stereo_centers', 'tpsa'
]

if st.button("Predict ADMET"):
    if smiles_input:
        features = extract_features([smiles_input])
        if features.isnull().values.any():
            st.error("Invalid SMILES string! Please enter a valid one.")
        else:
            features_scaled = scaler.transform(features)
            predictions = best_model.predict(features_scaled).flatten()
            predicted_admet = dict(zip(selected_admet, predictions))

            st.subheader("📊 Predicted & Evaluated ADMET Properties")

            score = 0
            max_score = len(selected_admet)

            st.warning("Absorption Properties")
            for prop in ['HIA_Hou', 'PAMPA_NCATS', 'Pgp_Broccatelli', 'Caco2_Wang']:
                val = predicted_admet.get(prop, None)
                if val is not None:
                    interpretation = interpret_property(prop, val)
                    st.write(f"**{prop}**: {val:.4f} — {interpretation}")
            st.write("------------")

            st.warning("Distribution Properties")
            for prop in ['BBB_Martins', 'Bioavailability_Ma','PPBR_AZ', 'Lipophilicity_AstraZeneca']:
                val = predicted_admet.get(prop, None)
                if val is not None:
                    interpretation = interpret_property(prop, val)
                    st.write(f"**{prop}**: {val:.4f} — {interpretation}")
            st.write("------------")

            st.warning("Metabolism Properties")
            for prop in ['CYP1A2_Veith','CYP2C19_Veith','CYP2C9_Substrate_CarbonMangels','CYP2C9_Veith',
                         'CYP2D6_Substrate_CarbonMangels','CYP2D6_Veith','CYP3A4_Substrate_CarbonMangels','CYP3A4_Veith']:
                val = predicted_admet.get(prop, None)
                if val is not None:
                    interpretation = interpret_property(prop, val)
                    st.write(f"**{prop}**: {val:.4f} — {interpretation}")
            st.write("------------")

            st.warning("Excretion Properties")
            for prop in ['Clearance_Hepatocyte_AZ', 'Clearance_Microsome_AZ', 'Half_Life_Obach', 'VDss_Lombardo']:
                val = predicted_admet.get(prop, None)
                if val is not None:
                    interpretation = interpret_property(prop, val)
                    st.write(f"**{prop}**: {val:.4f} — {interpretation}")
            st.write("------------")

            st.warning("Toxicity Properties")
            for prop in ['AMES','Carcinogens_Lagunin','ClinTox','DILI', 'hERG', 'Skin_Reaction']:
                val = predicted_admet.get(prop, None)
                if val is not None:
                    interpretation = interpret_property(prop, val)
                    st.write(f"**{prop}**: {val:.4f} — {interpretation}")
            st.write("------------")

            st.warning("Other Properties")
            for prop in ['molecular_weight', 'logP', 'hydrogen_bond_acceptors', 'hydrogen_bond_donors', 'Lipinski', 
                         'QED', 'stereo_centers', 'tpsa']:
                val = predicted_admet.get(prop, None)
                if val is not None:
                    interpretation = interpret_property(prop, val)
                    if prop in ['hydrogen_bond_acceptors', 'hydrogen_bond_donors', 'Lipinski', 'stereo_centers']:
                        val = round(val)
                    st.write(f"**{prop}**: {val:.4f} — {interpretation}")
            
    else:
        st.warning("Please enter a SMILES string.")


st.subheader("📚 Interpretation Ranges Reference")

# Absorption Properties
st.markdown("### 🧪 Absorption Properties")
st.markdown("- **HIA_Hou**: ≥30% 🟢 Excellent; <30% 🔴 Poor")
st.markdown("- **PAMPA_NCATS**: ≥1.0 × 10⁻⁶ cm/s 🟢 High permeability; <1.0 × 10⁻⁶ cm/s 🔴 Low")
st.markdown("- **Pgp_Broccatelli**: 0 🔵 Non-substrate; 1 🟠 Substrate")
st.markdown("- **Caco2_Wang**: > -5.15 🟢 Excellent permeability; ≤ -5.15 🔴 Poor")

# Distribution Properties
st.write(" ")
st.markdown("### 🔄 Distribution Properties")
st.markdown("- **BBB_Martins**: ≥0.1 🟢 Likely to cross BBB; <0.1 🔴 Unlikely")
st.markdown("- **Bioavailability_Ma**: ≥0.7 🟢 High; 0.3–0.7 🟡 Medium; <0.3 🔴 Low")
st.markdown("- **PPBR_AZ**: <90% 🟢 Low protein binding; ≥90% 🔴 High binding")
st.markdown("- **Lipophilicity_AstraZeneca** (LogD): -1 to 3 🟢 Optimal; outside this 🔴 Suboptimal")

# Metabolism Properties
st.write(" ")
st.markdown("### ⚙️ Metabolism Properties")
metabolism_props = [
    'CYP1A2_Veith', 'CYP2C19_Veith', 'CYP2C9_Substrate_CarbonMangels', 'CYP2C9_Veith',
    'CYP2D6_Substrate_CarbonMangels', 'CYP2D6_Veith', 'CYP3A4_Substrate_CarbonMangels', 'CYP3A4_Veith'
]
for prop in metabolism_props:
    st.markdown(f"- **{prop}**: ≤0.3 🟢 Low likelihood; 0.3–0.7 🟡 Moderate; >0.7 🔴 High likelihood")

# Excretion Properties
st.write(" ")
st.markdown("### 💧 Excretion Properties")
st.markdown("- **Clearance_Hepatocyte_AZ**: ≥5 mL/min/kg 🟢 Efficient; <5 🔴 Poor")
st.markdown("- **Clearance_Microsome_AZ**: ≥5 μL/min/mg 🟢 High clearance; <5 🔴 Low")
st.markdown("- **Half_Life_Obach**: ≥3 h 🟢 Long half-life; <3 h 🔴 Short")
st.markdown("- **VDss_Lombardo**: 0.04–20 L/kg 🟢 Acceptable distribution; outside 🔴 Atypical")

# Toxicity Properties
st.write(" ")
st.markdown("### ☠️ Toxicity Properties")
tox_props = ['AMES', 'Carcinogens_Lagunin', 'DILI', 'hERG', 'Skin_Reaction']
for prop in tox_props:
    st.markdown(f"- **{prop}**: ≤0.3 🟢 Low risk; 0.3–0.7 🟡 Medium; >0.7 🔴 High risk")
st.markdown("- **ClinTox**: ≤0.5 ✅ Safe; >0.5 ⚠️ Toxic concern")

# Other Properties
st.write(" ")
st.markdown("### 📊 Other Molecular Properties")
st.markdown("- **molecular_weight**: 100–500 Da 🟢 Optimal; outside 🔴 Non-optimal")
st.markdown("- **logP**: ≤5 🟢 Lipophilic; >5 🔴 Too lipophilic (Lipinski rule)")
st.markdown("- **hydrogen_bond_acceptors**: ≤10 🟢 Acceptable; >10 🔴 Violates Lipinski")
st.markdown("- **hydrogen_bond_donors**: ≤5 🟢 Acceptable; >5 🔴 Violates Lipinski")
st.markdown("- **Lipinski**: 0 🟢 Drug-like; ≥1 🔴 Violates rules")
st.markdown("- **QED**: ≥0.7 🟢 High; 0.4–0.7 🟡 Medium; <0.4 🔴 Low")
st.markdown("- **stereo_centers**: ≤10 🟢 Manageable; >10 🔴 Complex synthesis")
st.markdown("- **tpsa** (Topological Polar Surface Area): ≤140 Å² 🟢 Good absorption; >140 🔴 Poor absorption")