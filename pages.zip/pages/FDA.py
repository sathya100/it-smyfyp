import requests
import pandas as pd
import numpy as np
from rdkit import Chem
from rdkit.Chem import Descriptors
from sklearn.preprocessing import StandardScaler
import streamlit as st

# Ensure page config is set before any Streamlit commands
st.set_page_config(
    page_title="FDA Drug Side Effects Explorer",
    layout="wide",
    initial_sidebar_state="expanded"
)

# ---------- Configuration ----------
SIDER_PATH = "/Users/diyaarshiya/Documents/FYP/FYP sem8/merged_output_final1.csv"
SCORES_PATH = "/Users/diyaarshiya/Documents/FYP/FYP sem8/rev2 code/scoring_sider.xlsx"

# ---------- Load Data ----------
@st.cache_data
def load_data():
    sider_df = pd.read_csv(SIDER_PATH, encoding="ISO-8859-1")
    scores_df = pd.read_excel(SCORES_PATH, engine='openpyxl')
    scores_df["Name"] = scores_df["Name"].str.lower()
    severity = dict(zip(scores_df["Name"], scores_df["Rank score"]))
    frequency = dict(zip(scores_df["Name"], scores_df["Rank Stdev (% out 2929)"]))
    return sider_df, severity, frequency

sider_df, severity_dict, frequency_dict = load_data()

# ---------- Helper Functions ----------
def get_smiles_from_generic_name(generic_name):
    try:
        url = (
            "https://pubchem.ncbi.nlm.nih.gov/rest/pug/compound/"
            f"name/{generic_name.replace(' ', '+')}/property/CanonicalSMILES/JSON"
        )
        r = requests.get(url, timeout=10)
        r.raise_for_status()
        return r.json()["PropertyTable"]["Properties"][0].get("CanonicalSMILES")
    except:
        return None


def map_similar_side_effects(side_effects_list):
    mapping = {
        "abdominal pain": ["abdominal discomfort", "abdominal distension", "abdominal pain upper", "abdominal pain lower"],
        "rash": ["skin rash", "maculopapular rash", "erythematous rash", "rash maculopapular"],
        "headache": ["minor headache", "severe headache", "migraine"],
    }
    out = []
    for se in side_effects_list:
        se_low = se.lower()
        for cat, terms in mapping.items():
            if any(t in se_low for t in terms):
                out.append(cat)
                break
        else:
            out.append(se_low)
    return out


def fetch_drug_info(disease_name: str):
    base_url = "https://api.fda.gov/drug/label.json"
    params = {"search": f"indications_and_usage:{disease_name}", "limit": 30}
    detailed_drugs = []
    seen = set()
    resp = requests.get(base_url, params=params, timeout=10)
    resp.raise_for_status()
    for rec in resp.json().get("results", []):
        od = rec.get("openfda", {})
        gen = od.get("generic_name", ["Unknown"])[0]
        if gen in seen or gen == "Unknown":
            continue
        bn = od.get("brand_name", ["Unknown"])[0]
        smiles = get_smiles_from_generic_name(gen)
        if not smiles:
            continue
        seen.add(gen)
        ses = sider_df.loc[
            (sider_df["name"].str.lower() == gen.lower()) &
            (sider_df["pref_left"] == "PT"), "se"
        ].dropna().tolist()
        mapped = map_similar_side_effects(ses)
        cum_score = 0.0
        valid_n = 0
        details = []
        for se in mapped:
            sev = severity_dict.get(se)
            freq = frequency_dict.get(se)
            if sev is not None and freq is not None:
                prod = sev * freq
                cum_score += prod
                valid_n += 1
                details.append((se, sev, freq, prod))
            else:
                details.append((se, None, None, None))
        norm_score = (cum_score / valid_n) if valid_n else None
        detailed_drugs.append({
            "Brand Name": bn,
            "Generic Name": gen,
            "SMILES": smiles,
            "Details": details,
            "Normalized Score": norm_score
        })
    return detailed_drugs

# ---------- Streamlit UI ----------
st.title("FDA Drug Side Effects")
disease = st.text_input("Enter a disease name:", "")

if disease:
    with st.spinner("Fetching drugs and side effects..."):
        try:
            drugs = fetch_drug_info(disease)
            if not drugs:
                st.warning(f"No FDA-approved drugs found for '{disease}'.")
            else:
                st.success(f"FDA approved Drugs for {disease}")
                c=1
                for i in drugs:
                    st.write(f"{c}. {i["Generic Name"]}")

                st.write("--------------------------------")
                st.subheader("Side Effect Severity calculation for Drugs 💊")

                for drug in drugs:
                    st.subheader(f"{drug['Generic Name']} ({drug['Brand Name']})")
                    st.markdown(f"**SMILES**: `{drug['SMILES']}`")

                    # Side effects table
                    st.markdown("**Top 15 Side Effects**")
                    table = []
                    for se, sev, freq, prod in drug['Details'][:15]:
                        table.append({
                            "Side Effect": se,
                            "Severity": sev if sev is not None else "N/A",
                            "Frequency": freq if freq is not None else "N/A",
                        })
                    st.table(pd.DataFrame(table))

                    # Normalized score
                    st.markdown(
                        f"**Normalized Cumulative Score**: `{round(drug['Normalized Score'], 2) if drug['Normalized Score'] is not None else 'N/A'}`"
                    )
                    st.markdown("---")
        except Exception as e:
            st.error(f"An error occurred: {e}")
